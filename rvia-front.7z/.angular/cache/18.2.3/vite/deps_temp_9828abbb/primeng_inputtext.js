import {
  InputText,
  InputTextModule
} from "./chunk-BW5VOL7L.js";
import "./chunk-IDNO4BOS.js";
import "./chunk-C42PCG6B.js";
import "./chunk-AXD5F3UA.js";
import "./chunk-QHR5VV25.js";
import "./chunk-FDESMX7I.js";
import "./chunk-WDMUDEB6.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map

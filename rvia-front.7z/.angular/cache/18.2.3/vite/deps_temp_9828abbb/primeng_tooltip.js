import {
  Tooltip,
  TooltipModule
} from "./chunk-3DVOJZQ6.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-C42PCG6B.js";
import "./chunk-AXD5F3UA.js";
import "./chunk-QHR5VV25.js";
import "./chunk-FDESMX7I.js";
import "./chunk-WDMUDEB6.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map

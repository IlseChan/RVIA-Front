import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-F7L2ZNIJ.js";
import "./chunk-WODX4MUU.js";
import "./chunk-PE6XBOET.js";
import "./chunk-OVPESPS2.js";
import "./chunk-6K5PCH7R.js";
import "./chunk-QU7AFVGG.js";
import "./chunk-C42PCG6B.js";
import "./chunk-AXD5F3UA.js";
import "./chunk-QHR5VV25.js";
import "./chunk-FDESMX7I.js";
import "./chunk-WDMUDEB6.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map

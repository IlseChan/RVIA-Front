export interface FormAddonCall {
    idu_aplicacion:   number;
    conIA:            number;
    opc_arquitectura: number;
}
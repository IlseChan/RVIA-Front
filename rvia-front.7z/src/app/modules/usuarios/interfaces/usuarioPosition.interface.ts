import { Idu_Rol } from "./iduRol.enum";
import { Nom_Rol } from "./nomRol.enum";

export interface Position {
    idu_rol: Idu_Rol;
    nom_rol: Nom_Rol
}
import { Usuario } from "./usuario.interface";

export interface UsersData {
    data:  Usuario[];
    total: number;
}
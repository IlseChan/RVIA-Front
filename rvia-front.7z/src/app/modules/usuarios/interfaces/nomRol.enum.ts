export enum Nom_Rol {
    ADMINISTRADOR = 'Administrador',  
    AUTORIZADOR   = 'Autorizador',
    INVITADO      = 'Invitado',
    USUARIO       = 'Usuario',
}
export enum Idu_Rol {
    ADMINISTRADOR = 1,
    AUTORIZADOR   = 2,
    USUARIO       = 3,
    INVITADO      = 4
}
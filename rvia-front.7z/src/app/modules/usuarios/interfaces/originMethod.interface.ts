export enum OriginMethod {
    DELETEUSERS = 'DELETEUSERS',
    GETUSER     = 'GETUSER',
    GETUSERS    = 'GETUSERS',
    UPDATEUSER  = 'UPDATEUSER' 
}
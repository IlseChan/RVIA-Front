import { Aplication } from "./aplicacion.interface";

export interface AplicationsData {
    data:  Aplication[];
    total: number;
}
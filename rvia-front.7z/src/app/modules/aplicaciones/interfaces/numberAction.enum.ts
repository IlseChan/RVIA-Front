export enum NumberAction {
    NONE         = 0,  
    UPDATECODE   = 1,
    SANITIZECODE = 2,
    MIGRATION    = 3,
}
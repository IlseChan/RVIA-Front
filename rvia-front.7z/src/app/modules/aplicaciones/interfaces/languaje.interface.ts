export interface Language {
    idu_lenguaje: number;
    nom_lenguaje: string;
}
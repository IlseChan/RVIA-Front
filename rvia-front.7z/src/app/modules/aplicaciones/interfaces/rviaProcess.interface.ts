export interface RviaProcess {
    isValidProcess: boolean;
    messageRVIA:    string;
}
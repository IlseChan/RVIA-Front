export interface AppsToUseSelect {
    value: number;
    name:  string;
}
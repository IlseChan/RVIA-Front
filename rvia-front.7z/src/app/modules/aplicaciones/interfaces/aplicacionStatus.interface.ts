import { StatusApp } from '@modules/aplicaciones/interfaces/statusApp.enum';

export interface ApplicationStatus {
    des_estatus_aplicacion: string;
    idu_estatus_aplicacion: StatusApp;
}

export interface Opt_architec {
    [key: number]: boolean;
    1: boolean,
    2: boolean,
    3: boolean,
    4: boolean
}
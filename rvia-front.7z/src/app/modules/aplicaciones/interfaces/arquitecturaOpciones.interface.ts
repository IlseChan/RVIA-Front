export enum ArquitecturaOpciones {
    DOC_CMPLT  = 1,  
    DOC_CODE   = 2,      
    TEST_CASES = 3,              
    EVALUATION = 4               
}
import { StatusAppLabelPipe } from './status-app-label.pipe';

describe('StatusAppLabelPipe', () => {
  it('create an instance', () => {
    const pipe = new StatusAppLabelPipe();
    expect(pipe).toBeTruthy();
  });
});

import { StatusAppPipe } from './status-app.pipe';

describe('StatusAppPipe', () => {
  it('create an instance', () => {
    const pipe = new StatusAppPipe();
    expect(pipe).toBeTruthy();
  });
});

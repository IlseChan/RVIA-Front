import { ActionAppPipe } from './action-app.pipe';

describe('ActionAppPipe', () => {
  it('create an instance', () => {
    const pipe = new ActionAppPipe();
    expect(pipe).toBeTruthy();
  });
});

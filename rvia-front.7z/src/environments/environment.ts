export const environment = {
    production: false,
    baseURL: 'http://localhost:3001'
}